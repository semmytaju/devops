<?php 
	// load core classes
	require_once('core/App.php');
	require_once('core/Controller.php');

	// load configuration file
    require_once('config/config.php');

    // start session
    //session_start();
?>
