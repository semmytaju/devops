<?php

	// define path constants
    define("APP_PATH", 'http://localhost/unkpresent/public');

    // define database config
    
?>