<div class="container">
	<h1>This is my Personal Page in Home.</h1>

	<p><b>Current page:</b> <?php echo $data['current']; ?> </p>

	<p><b>Next page:</b> <?php echo $data['next']; ?> </p>

	<p><b>Previous page:</b> <?php echo $data['previous']; ?> </p>
</div>