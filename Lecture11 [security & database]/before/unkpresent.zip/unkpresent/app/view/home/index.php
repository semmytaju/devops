<div class="container">
	<h1>This is my Home Page.</h1>
	
	<p>I'm <?php echo $data['name']; ?> from Manado.</p>
	
	<p>I'm <?php echo $data['age']; ?> years old this year.</p>

	<img src="<?php echo APP_PATH; ?>/img/test.png" alt="test image" width="200" class="rounded-circle shadow">
</div>
