<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF=8">
	<title>Project Page</title>
</head>
<body>
	<h1>This is my Project Page.</h1>
	<p>I'm happy to learn this course.</p>
</body>
</html>