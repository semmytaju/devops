
<script src="<?php echo APP_PATH; ?>/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="<?php echo APP_PATH; ?>/js/bootstrap.min.js"></script>
<script src="<?php echo APP_PATH; ?>/js/bootstrap.min.js"></script>
<script src="<?php echo APP_PATH; ?>/js/jquery-3.3.1.slim.min.js"></script>

</body>
</html>