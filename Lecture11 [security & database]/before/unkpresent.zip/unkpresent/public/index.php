<?php 
	
	require_once('../app/init.php');

	// Create instance/object from class
	$app = new App(); 
?>