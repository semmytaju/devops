<?php
class project{
	// Constructor
	public function __construct(){

	}

	// Default method
	public function index(){
		echo "this is project/index";
	}

	public function publication(){
		echo "this is project/name";
	}

	public function donator(){
		echo "this is project/expire";
	}
}

?>