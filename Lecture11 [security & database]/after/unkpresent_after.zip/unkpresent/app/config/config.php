<?php

	// define path constants
    define("APP_PATH", "http://103.32.38.67/unkpresent/public");

    // define database config
    define("HOST_DB", "localhost");
    define("NAME_DB", "db_attendance");
    define("USER_DB", "phpmyadmin");
    define("PASS_DB", "123459999990");
	
	
?>