
<script type='text/javascript' src="<?php echo APP_PATH;?>/js/bootstrap.bundle.min.js"></script>
<script type='text/javascript' src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script type='text/javascript' src='https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js'></script>
<script type='text/javascript' src="<?php echo APP_PATH;?>/js/jquery-3.3.1.slim.min.js"></script>


</body>
</html>